from ..views import MenuItemsView
from django.test import TestCase
from ..models import Menu

class MenuViewTest(TestCase):
    def setUp(self):
        Menu.objects.create(title = "Cake", price = 20, inventory = 40)
        Menu.objects.create(title = "Coffee", price = 3, inventory = 100)
    
    def test_getall(self):
        menuitems = Menu.objects.all()